import Property from "../models/Property.js";

export const addProperty = async (req, res) => {
  try {
    const property = new Property(req.body);
    await property.save();
    res.status(201).json({ msg: "Property added", property });
  } catch (err) {
    console.error("Error saving property:", err.message);
    res.status(500).json({ msg: "Failed to add property" });
  }
};
