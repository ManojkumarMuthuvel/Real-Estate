# real-estate
First open vs code or any Idle domain
to run Open command prompt or vs code terminal

for client side
cmd 1.
cd C:\Users\DELL\Desktop\Real_Estate[1]\Real Estate\client-side

cmd 2. npm start

for server side
cmd 1.
cd C:\Users\DELL\Desktop\Real_Estate[1]\Real Estate\server-side

cmd 2. npm start


To see the Database 
open the mongodb Compass
open the Real estate db
