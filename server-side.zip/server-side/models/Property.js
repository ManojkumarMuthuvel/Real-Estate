const mongoose = require("mongoose");

const propertySchema = new mongoose.Schema({
  title: { type: String, required: true },
  rent: Number,
  advance: Number,
  type: { type: String, enum: ["Rent", "Sell"], default: "Rent" },
  bhkType: String,
  location: { type: String, required: true },
  parking: { type: String, enum: ["Yes", "No"] },
  family: { type: String, enum: ["Yes", "No"] },
  bachelor: [String],
  description: String,
  furnished: {
    type: String,
    enum: ["Furnished", "Semi-Furnished", "Unfurnished"],
  },
  images: [String],
  lat: Number,
  lng: Number,
    agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Agent", // Optional: only if you have an Agent model
    required: true
  },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Property", propertySchema);
