// models/Agent.js
import mongoose from "mongoose";

const agentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  agencyName: { type: String }, // optional
}, { timestamps: true });

export default mongoose.model("Agent", agentSchema);
