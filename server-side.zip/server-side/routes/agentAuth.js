// routes/agentAuth.js
import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Agent from "../models/Agent.js";

const router = express.Router();

router.post("/register", async (req, res) => {
  try {
    const { name, email, password, agencyName } = req.body;
    const exists = await Agent.findOne({ email });
    if (exists) return res.status(400).json({ msg: "Agent already exists" });

    const hashed = await bcrypt.hash(password, 10);
    const agent = await new Agent({ name, email, password: hashed, agencyName }).save();

    res.status(201).json({ msg: "Agent registered successfully" });
  } catch (err) {
    res.status(500).json({ msg: "Error", error: err.message });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const agent = await Agent.findOne({ email });
    if (!agent) return res.status(404).json({ msg: "Agent not found" });

    const match = await bcrypt.compare(password, agent.password);
    if (!match) return res.status(401).json({ msg: "Invalid credentials" });

    const token = jwt.sign({ id: agent._id, role: "agent" }, process.env.JWT_SECRET, { expiresIn: "2d" });
    res.json({ token, agent: { id: agent._id, name: agent.name, email: agent.email, role: "agent" } });
  } catch (err) {
    res.status(500).json({ msg: "Error", error: err.message });
  }
});

export default router;
