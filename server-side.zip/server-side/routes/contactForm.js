import express from "express";
import ContactForm from "../models/ContactForm.js";
import Property from "../models/Property.js";
import Agent from "../models/Agent.js";

const router = express.Router();

// POST: Create new contact form
router.post("/", async (req, res) => {
  try {
    const { name, email, phone, whatsapp, propertyId, toAgentId } = req.body;

    if (!name || !propertyId || !toAgentId) {
      return res.status(400).json({ msg: "Missing required fields" });
    }

    const newContact = new ContactForm({
      name,
      email,
      phone,
      whatsapp,
      propertyId,
      toAgentId,
    });

    await newContact.save();
    res.status(201).json({ msg: "Contact request submitted successfully" });
  } catch (err) {
    console.error("Error saving contact form:", err);
    res.status(500).json({ msg: "Server error", error: err.message });
  }
});

// GET: Fetch all contact forms for a specific agent
router.get("/agent/:agentId", async (req, res) => {
  try {
    const forms = await ContactForm.find({ toAgentId: req.params.agentId })
      .populate("propertyId", "title location rent")
      .sort({ createdAt: -1 });

    res.json(forms);
  } catch (err) {
    console.error("Failed to fetch contact forms:", err);
    res.status(500).json({ msg: "Server error", error: err.message });
  }
});

export default router;
