import express from "express";
import Request from "../models/Request.js";
import Chat from "../models/Chat.js"; 

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { fromUserId, toAgentId, propertyId, message } = req.body;

    if (!fromUserId || !toAgentId || !propertyId || !message) {
      return res.status(400).json({ msg: "All fields are required" });
    }

    const request = new Request({
      fromUserId,
      toAgentId,
      propertyId,
      message,
    });

    await request.save();

      const chatEntry = new Chat({
      fromUserId,
      toAgentId,
      propertyId,
      text: message,
    });
    await chatEntry.save();

    res.status(201).json({ msg: "Request sent successfully" });
  } catch (err) {
    console.error("Error saving request:", err.message);
    res.status(500).json({ msg: "Server error", error: err.message });
  }
});
// GET requests made by a specific user
router.get("/user/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    const requests = await Request.find({ fromUserId: userId })
      .populate("propertyId")
      .populate("toAgentId", "name email")
      .sort({ createdAt: -1 });

    res.json(requests);
  } catch (err) {
    console.error("Failed to fetch user requests:", err.message);
    res.status(500).json({ msg: "Server error", error: err.message });
  }
});

// PUT update status
router.put("/:id/status", async (req, res) => {
  try {
    const request = await Request.findById(req.params.id);
    if (!request) return res.status(404).json({ msg: "Request not found" });

    request.status = req.body.status;
    await request.save();

    res.json({ msg: "Status updated", request });
  } catch (err) {
    res.status(500).json({ msg: "Error updating request", error: err.message });
  }
});

// GET requests for an agent
router.get("/agent/:agentId", async (req, res) => {
  try {
    const requests = await Request.find({ toAgentId: req.params.agentId })
      .populate("propertyId")
      .populate("fromUserId", "name email"); // optional

    res.json(requests);
  } catch (err) {
    res.status(500).json({ msg: "Error fetching requests", error: err.message });
  }
});

// PUT: user replies to agent
router.put("/user-reply/:requestId", async (req, res) => {
  const { userReplyMessage } = req.body;
  try {
    const request = await Request.findByIdAndUpdate(
      req.params.requestId,
      { userReplyMessage },
      { new: true }
    );
    res.json({ msg: "Reply sent", request });
  } catch (err) {
    res.status(500).json({ msg: "Failed to send reply", error: err.message });
  }
});


export default router;
