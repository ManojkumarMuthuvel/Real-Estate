const express = require("express");
const router = express.Router();
const Property = require("../models/Property");

// POST /api/properties
router.post("/", async (req, res) => {
  try {
    const newProperty = new Property(req.body);
    const saved = await newProperty.save();
    res.status(201).json(saved);
  } catch (err) {
    console.error("Error saving property:", err.message);
    res.status(500).json({ msg: "Failed to add property", error: err.message });
  }
});

// GET /api/properties
router.get("/", async (req, res) => {
  try {
    const properties = await Property.find().sort({ createdAt: -1 });
    res.status(200).json(properties);
  } catch (err) {
    console.error("Error fetching properties:", err.message);
    res.status(500).json({ msg: "Failed to fetch properties", error: err.message });
  }
});


module.exports = router;
