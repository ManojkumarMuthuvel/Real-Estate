import express from "express";
import mongoose from "mongoose";
import multer from "multer";
import Agent from "../models/Agent.js";

const router = express.Router();

// Multer setup for profile image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Ensure this folder exists
  },
  filename: (req, file, cb) => {
    const ext = file.originalname.split(".").pop();
    cb(null, `${Date.now()}-${file.fieldname}.${ext}`);
  },
});

const upload = multer({ storage });

// ====================================
// GET: Fetch single agent by ID
// ====================================
router.get("/:id", async (req, res) => {
  try {
    const agent = await Agent.findById(req.params.id);
    if (!agent) {
      return res.status(404).json({ msg: "Agent not found" });
    }
    res.json(agent);
  } catch (err) {
    console.error("Error fetching agent:", err.message);
    res.status(500).json({ msg: "Server error", error: err.message });
  }
});

// ====================================
// PUT: Update agent profile
// ====================================
router.put("/:id", upload.single("profileImage"), async (req, res) => {
  try {
    const updateData = { ...req.body };
    if (req.file) {
      updateData.profileImage = `/uploads/${req.file.filename}`;
    }

    const updatedAgent = await Agent.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );

    if (!updatedAgent) {
      return res.status(404).json({ msg: "Agent not found" });
    }

    res.json(updatedAgent);
  } catch (err) {
    console.error("Error updating agent:", err.message);
    res.status(500).json({ msg: "Server error", error: err.message });
  }
});

export default router;
