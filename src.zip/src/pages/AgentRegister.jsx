import React, { useState } from "react";
import { FcGoogle } from "react-icons/fc";
import { FaFacebook } from "react-icons/fa";

import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from "react-router-dom";
const AgentRegister = () => {
  const navigate=useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/agent/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.msg || "Register failed");

      toast.success("✅ Agent registered successfully!");
      setFormData({ name: "", email: "", password: "" });
      navigate("/agent-login");
      // You may redirect to /agent-login here
    } catch (err) {
      toast.error(`❌ ${err.message}`);
    }
  };

  const handleSocialRegister = (provider) => {
    console.log(`Registering with ${provider}`);
    alert(`${provider} registration is not implemented yet.`);
  };

  return (
    <div className="min-h-screen flex">
       <Toaster position="top-right" />
      {/* Left Side - Form */}
      <div className="w-full md:w-1/2 bg-white flex items-center justify-center">
        <form onSubmit={handleSubmit} className="w-full max-w-sm p-8">
          <h2 className="text-3xl font-bold mb-6 text-gray-800">Agent Registration</h2>
          <p className="mb-6 text-gray-500">Create your agent account to list properties</p>

          <input
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full p-3 mb-4 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
            type="text"
            placeholder="Name"
            required
          />
          <input
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full p-3 mb-4 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
            type="email"
            placeholder="Email"
            required
          />
          <input
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="w-full p-3 mb-6 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
            type="password"
            placeholder="Password"
            required
          />

          <button
            type="submit"
            className="w-full bg-green-500 text-white p-3 rounded hover:bg-green-600 transition"
          >
            Register
          </button>

          {/* Divider */}
          <div className="flex items-center my-6">
            <div className="flex-grow h-px bg-gray-300"></div>
            <span className="px-3 text-sm text-gray-500">OR</span>
            <div className="flex-grow h-px bg-gray-300"></div>
          </div>

          {/* Social Register */}
          <button
            type="button"
            onClick={() => handleSocialRegister("Google")}
            className="w-full flex items-center justify-center gap-2 bg-white border border-gray-300 rounded p-2 mb-3 shadow-sm hover:shadow transition"
          >
            <FcGoogle size={20} />
            <span className="text-sm text-gray-700">Continue with Google</span>
          </button>

          <button
            type="button"
            onClick={() => handleSocialRegister("Facebook")}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white rounded p-2 shadow hover:bg-blue-700 transition"
          >
            <FaFacebook size={20} />
            <span className="text-sm">Continue with Facebook</span>
          </button>

          <p className="mt-4 text-sm text-gray-600 text-center">
            Already have an agent account?{" "}
            <a href="/agent-login" className="text-green-600 hover:underline">
              Login here
            </a>
          </p>
        </form>
      </div>

      {/* Right Side - Image */}
      <div
        className="hidden md:flex w-1/2 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1570129477492-45c003edd2be')",
        }}
      ></div>
    </div>
  );
};

export default AgentRegister;
