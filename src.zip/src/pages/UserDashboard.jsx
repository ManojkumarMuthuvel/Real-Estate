// Updated UserDashboard.jsx with PropertyModal support

import React, { useState, useEffect } from "react";
import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";
import PropertyGrid from "../components/property/PropertyGrid";

import Requests from "../components/requests/Requests";

import PropertyModal from "../components/property/PropertyModal";

import Profile from "../components/Profile/Profile";

const UserDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [activePage, setActivePage] = useState("Home");
  const [selectedProperty, setSelectedProperty] = useState(null);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarCollapsed(true);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handlePropertyClick = (property) => {
    setSelectedProperty(property);
  };

  const closeModal = () => {
    setSelectedProperty(null);
  };

  return (
    <div className="relative min-h-screen">
      <video
        autoPlay
        loop
        muted
        className="absolute inset-0 w-full h-full object-cover z-0"
        src="/real-estate.mp4"
      ></video>
      <div className="relative z-10 flex min-h-screen bg-black/50">
        <Sidebar
  collapsed={isSidebarCollapsed}
  toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
  activePage={activePage}
  setActivePage={setActivePage}
  role="user"
/>

        <div className="flex flex-col flex-1">
          <Header />
          <main className="p-6">
            {activePage === "Home" && <PropertyGrid onPropertyClick={handlePropertyClick} />}
            {activePage === "Profile" && <Profile/>}

           
            {activePage === "Requests" && <Requests />}
          </main>
        </div>
      </div>
      {selectedProperty && (
        <PropertyModal property={selectedProperty} onClose={closeModal} />
      )}
    </div>
  );
};

export default UserDashboard;
