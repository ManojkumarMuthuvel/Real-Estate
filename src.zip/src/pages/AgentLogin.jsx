import React, { useState } from "react";
import { FcGoogle } from "react-icons/fc";
import { FaFacebook } from "react-icons/fa";
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from "react-router-dom";
const AgentLogin = () => {
  const navigate= useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("http://localhost:5000/api/agent/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.msg || "Login failed");

      toast.success("✅ Agent logged in successfully!");
      localStorage.setItem("agentId", data.agent.id);
      localStorage.setItem("agentName", data.agent.name);

      console.log(localStorage.getItem("agentId"));
      console.log(data.agent.id);
      setFormData({ email: "", password: "" });
      navigate('/dashboard')
      // You could redirect or store token here
    } catch (err) {
      toast.error(`❌ ${err.message}`);
    }
  };

  const handleSocialLogin = (provider) => {
    console.log(`Logging in with ${provider}`);
    toast.error(`${provider} login is not implemented yet.`);
  };

  return (
    <div className="min-h-screen flex">
       <Toaster position="top-right" />
      {/* Left Side - Form */}
      <div className="w-full md:w-1/2 bg-white flex items-center justify-center">
        <form onSubmit={handleSubmit} className="w-full max-w-sm p-8">
          <h2 className="text-3xl font-bold mb-6 text-gray-800">Agent Login</h2>
          <p className="mb-6 text-gray-500">Access your dashboard and manage properties</p>

          <input
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full p-3 mb-4 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            type="email"
            placeholder="Email"
            required
          />
          <input
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="w-full p-3 mb-6 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            type="password"
            placeholder="Password"
            required
          />

          <button
            type="submit"
            className="w-full bg-blue-600 text-white p-3 rounded hover:bg-blue-700 transition"
          >
            Login
          </button>

          {/* Divider */}
          <div className="flex items-center my-6">
            <div className="flex-grow h-px bg-gray-300"></div>
            <span className="px-3 text-sm text-gray-500">OR</span>
            <div className="flex-grow h-px bg-gray-300"></div>
          </div>

          {/* Social logins */}
          <button
            type="button"
            onClick={() => handleSocialLogin("Google")}
            className="w-full flex items-center justify-center gap-2 bg-white border border-gray-300 rounded p-2 mb-3 shadow-sm hover:shadow transition"
          >
            <FcGoogle size={20} />
            <span className="text-sm text-gray-700">Continue with Google</span>
          </button>

          <button
            type="button"
            onClick={() => handleSocialLogin("Facebook")}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white rounded p-2 shadow hover:bg-blue-700 transition"
          >
            <FaFacebook size={20} />
            <span className="text-sm">Continue with Facebook</span>
          </button>

          <p className="mt-4 text-sm text-gray-600 text-center">
            Don’t have an agent account?{" "}
            <a href="/agent-register" className="text-blue-600 hover:underline">
              Register here
            </a>
          </p>
        </form>
      </div>

      {/* Right Side - Image */}
      <div
        className="hidden md:flex w-1/2 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1560448070-c3e8229db1f1')",
        }}
      ></div>
    </div>
  );
};

export default AgentLogin;
