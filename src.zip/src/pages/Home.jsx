// Landing Page - Home.jsx

import React from "react";
import { useNavigate } from "react-router-dom";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

const properties = [
  {
    id: 1,
    title: "Luxury Apartment in Mumbai",
    img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
  },
  {
    id: 2,
    title: "Modern Villa in Bangalore",
    img: "https://images.unsplash.com/photo-1572120360610-d971b9b78825",
  },
  {
    id: 3,
    title: "Cozy Flat in Hyderabad",
    img: "https://images.unsplash.com/photo-1599423300746-b62533397364",
  },
];

const Home = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate("/login");
  };

  return (
    <div className="min-h-screen text-white">
      {/* Floating Info Button */}
      <button
        onClick={() =>
          document.getElementById("how-to-use").scrollIntoView({ behavior: "smooth" })
        }
        className="absolute top-6 right-6 bg-white/80 text-blue-600 p-2 rounded-full shadow hover:bg-white z-50"
        title="How to use this site"
      >
        ℹ️
      </button>

      {/* Background banner */}
      <div
        className="h-[60vh] bg-cover bg-center flex items-center justify-center text-center"
        style={{
          backgroundImage:
            "url(https://images.unsplash.com/photo-1568605114967-8130f3a36994)",
        }}
      >
        <h1 className="text-5xl font-bold bg-black/60 px-4 py-2 rounded">
          Welcome to Real Estate
        </h1>
      </div>

      {/* Carousel Section */}
      <div className="bg-black/60 py-10 px-4">
        <h2 className="text-3xl font-bold text-center mb-6">Featured Properties</h2>
        <Carousel
          autoPlay
          infiniteLoop
          showThumbs={false}
          showStatus={false}
          interval={3000}
        >
          {properties.map((property) => (
            <div
              key={property.id}
              onClick={handleClick}
              className="cursor-pointer"
            >
              <img
                src={property.img}
                alt={property.title}
                className="rounded-lg object-cover h-[400px] mx-auto"
              />
              <p className="legend text-lg font-semibold">{property.title}</p>
            </div>
          ))}
        </Carousel>
      </div>

      {/* About Section */}
      <div className="bg-white text-gray-800 py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl font-bold mb-4">About Our Site</h3>
          <p className="text-lg">
            We provide a seamless way to buy, sell, or rent properties across major
            cities. Our user-friendly dashboard lets agents manage listings, while
            users can browse and inquire with ease. Sign up today to explore your
            dream home!
          </p>
        </div>
      </div>

      {/* How to Use Section */}
      <div id="how-to-use" className="bg-gray-100 text-gray-800 py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h3 className="text-2xl font-bold mb-8">How to Use This Site</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
            {/* Users */}
            <div className="bg-white p-6 rounded shadow">
              <h4 className="text-xl font-semibold mb-3">For Users</h4>
              <ul className="list-disc ml-5 space-y-2">
                <li>Search for properties based on location, type, and price.</li>
                <li>View detailed listings with photos and map locations.</li>
                <li>Save favorites and request visits.</li>
              </ul>
              <a href="/register" className="text-blue-600 mt-4 inline-block hover:underline">
                Register as User →
              </a>
            </div>

            {/* Agents */}
            <div className="bg-white p-6 rounded shadow">
              <h4 className="text-xl font-semibold mb-3">For Agents</h4>
              <ul className="list-disc ml-5 space-y-2">
                <li>Login to the agent dashboard to manage properties.</li>
                <li>Add property details, images, and set availability.</li>
                <li>Respond to user requests quickly and efficiently.</li>
              </ul>
              <a href="/agent-register" className="text-green-600 mt-4 inline-block hover:underline">
                Register as Agent →
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
