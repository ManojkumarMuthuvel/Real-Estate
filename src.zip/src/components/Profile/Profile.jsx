import React, { useEffect, useState } from "react";

const Profile = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    address: "",
    age: "",
    phone: "",
    profileImage: "",
  });
  const [preview, setPreview] = useState("");
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    fetch(`http://localhost:5000/api/users/${userId}`)
      .then((res) => res.json())
      .then(setUser)
      .catch((err) => console.error("Failed to load user:", err));
  }, [userId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setUser((prev) => ({ ...prev, profileImage: file }));
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    for (let key in user) formData.append(key, user[key]);

    try {
      const res = await fetch(`http://localhost:5000/api/users/${userId}`, {
        method: "PUT",
        body: formData,
      });
      const data = await res.json();
      if (res.ok) {
        alert("✅ Profile updated successfully!");
      } else {
        throw new Error(data.msg || "Update failed");
      }
    } catch (err) {
      alert("❌ " + err.message);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6 text-white bg-white/10 rounded-lg backdrop-blur-md">
      <h2 className="text-2xl font-bold mb-4">Update Profile</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Profile Image */}
        <div className="flex items-center gap-4">
          <img
            src={preview || user.profileImage || "https://via.placeholder.com/100"}
            alt="Profile"
            className="w-24 h-24 object-cover rounded-full border"
          />
          <input type="file" accept="image/*" onChange={handleFileChange} />
        </div>

        <input
          type="text"
          name="name"
          value={user.name}
          onChange={handleChange}
          placeholder="Full Name"
          className="w-full p-2 rounded text-black"
        />

        <input
          type="email"
          name="email"
          value={user.email}
          onChange={handleChange}
          placeholder="Email"
          className="w-full p-2 rounded text-black"
        />

        <input
          type="text"
          name="phone"
          value={user.phone}
          onChange={handleChange}
          placeholder="Phone Number"
          className="w-full p-2 rounded text-black"
        />

        <input
          type="text"
          name="address"
          value={user.address}
          onChange={handleChange}
          placeholder="Address"
          className="w-full p-2 rounded text-black"
        />

        <input
          type="number"
          name="age"
          value={user.age}
          onChange={handleChange}
          placeholder="Age"
          className="w-full p-2 rounded text-black"
        />

        <button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded"
        >
          Save Changes
        </button>
      </form>
    </div>
  );
};

export default Profile;
