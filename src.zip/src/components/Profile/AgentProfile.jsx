import React, { useEffect, useState } from "react";

const AgentProfile = () => {
  const agentId = localStorage.getItem("agentId");
  const [agent, setAgent] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    age: "",
    bio: "",
    profileImage: null,
  });

  useEffect(() => {
    fetch(`http://localhost:5000/api/agents/${agentId}`)
      .then((res) => res.json())
      .then((data) => {
        setAgent(data);
        setFormData({
          name: data.name || "",
          email: data.email || "",
          phone: data.phone || "",
          address: data.address || "",
          age: data.age || "",
          bio: data.bio || "",
          profileImage: null,
        });
      })
      .catch((err) => console.error("Failed to load agent data", err));
  }, [agentId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    setFormData((prev) => ({ ...prev, profileImage: e.target.files[0] }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    Object.keys(formData).forEach((key) => {
      if (formData[key]) data.append(key, formData[key]);
    });

    try {
      const res = await fetch(`http://localhost:5000/api/agents/${agentId}`, {
        method: "PUT",
        body: data,
      });

      const updated = await res.json();
      alert("✅ Profile updated successfully!");
      setAgent(updated);
    } catch (err) {
      console.error("Update error:", err);
      alert("❌ Failed to update profile");
    }
  };

  return (
    <div className="p-6 text-white max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Agent Profile</h2>

      <form onSubmit={handleSubmit} className="space-y-4 bg-white/10 p-6 rounded-lg">
        {agent?.profileImage && (
          <img
            src={`http://localhost:5000${agent.profileImage}`}
            alt="Profile"
            className="w-32 h-32 object-cover rounded-full mb-4"
          />
        )}

        <div>
          <label className="block mb-1">Profile Image</label>
          <input type="file" accept="image/*" onChange={handleFileChange} />
        </div>

        <div>
          <label className="block mb-1">Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full p-2 rounded text-black"
          />
        </div>

        <div>
          <label className="block mb-1">Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full p-2 rounded text-black"
          />
        </div>

        <div>
          <label className="block mb-1">Phone</label>
          <input
            type="text"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className="w-full p-2 rounded text-black"
          />
        </div>

        <div>
          <label className="block mb-1">Address</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            className="w-full p-2 rounded text-black"
          />
        </div>

        <div>
          <label className="block mb-1">Age</label>
          <input
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            className="w-full p-2 rounded text-black"
          />
        </div>

        <div>
          <label className="block mb-1">Bio</label>
          <textarea
            name="bio"
            value={formData.bio}
            onChange={handleChange}
            className="w-full p-2 rounded text-black"
          />
        </div>

        <button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded text-white font-semibold"
        >
          Update Profile
        </button>
      </form>
    </div>
  );
};

export default AgentProfile;
