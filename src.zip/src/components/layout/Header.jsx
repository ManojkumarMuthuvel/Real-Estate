import React from "react";

const Header = () => {
  const agentName = localStorage.getItem("agentName") || "Agent";
  return (
    <header className="bg-white/10 backdrop-blur-md p-4 shadow-md text-white border-b border-white/20">
      <h1 className="text-xl font-semibold">Welcome {agentName} from Real Estate Properties</h1>
    </header>
  );
};

export default Header;
