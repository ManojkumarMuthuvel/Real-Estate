import React from "react";
import {
  Home,
  Plus,
  Bell,
  Settings,
  Mail,
  ClipboardList,
  ChevronLeft,
  ChevronRight,
  User,
} from "lucide-react";

const Sidebar = ({ collapsed, toggleCollapse, activePage, setActivePage, role = "user" }) => {
  const menu = role === "agent"
    ? [
        { icon: <Home size={20} />, label: "Home" },
        { icon: <Plus size={20} />, label: "Add Property" },
        { icon: <ClipboardList size={20} />, label: "Requests" },
        { icon: <Mail size={20} />, label: "Contact Forms" },
   
        { icon: <User size={20} />, label: "Profile" },
      ]
    : [
        { icon: <Home size={20} />, label: "Home" },

        { icon: <ClipboardList size={20} />, label: "Requests" },
   
        { icon: <User size={20} />, label: "Profile" },
      ];

  return (
    <aside className={`h-screen ${collapsed ? 'w-20' : 'w-64'} transition-all duration-300 relative bg-white/10 backdrop-blur-lg p-4`}>
      <div className="flex items-center justify-between mb-6">
        {!collapsed && (
          <h1 className="text-2xl font-bold text-white">
            {role === "agent" ? "Agent Dashboard" : "User Dashboard"}
          </h1>
        )}
        <button
          onClick={toggleCollapse}
          className="absolute -right-4 top-4 bg-white text-gray-700 shadow p-1 rounded-full z-30 border"
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>
      <ul className="space-y-4">
        {menu.map((item, idx) => {
          const isActive = activePage === item.label;
          return (
            <li
              key={idx}
              onClick={() => setActivePage(item.label)}
              className={`flex items-center gap-3 cursor-pointer px-3 py-2 rounded-md hover:bg-white/20 transition ${
                isActive ? "text-blue-500 bg-white/20" : "text-white/80 hover:text-blue-400"
              }`}
            >
              {item.icon}
              {!collapsed && <span>{item.label}</span>}
            </li>
          );
        })}
      </ul>
    </aside>
  );
};

export default Sidebar;
