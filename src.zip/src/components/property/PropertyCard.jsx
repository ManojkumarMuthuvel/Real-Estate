import React from "react";

const PropertyCard = ({ image, price, address, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="cursor-pointer bg-white/10 text-white border border-white/20 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition"
    >
      <img src={image} alt="Property" className="w-full h-48 object-cover" />
      <div className="p-4">
        <h3 className="text-lg font-bold">{price}</h3>
        <p className="text-white/80 text-sm">{address}</p>
      </div>
    </div>
  );
};

export default PropertyCard;
