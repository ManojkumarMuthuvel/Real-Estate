import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import toast, { Toaster } from "react-hot-toast";

// Fix leaflet icon issue
delete L.Icon.Default.prototype._getIcon
L.Icon.Default.mergeOptions({
  iconUrl: "https://unpkg.com/leaflet@1.9.3/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png",
});

const inputClass =
  "w-full p-3 rounded-md bg-white/10 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-blue-500 transition shadow-sm";
const selectClass =
  "w-full p-3 rounded-md bg-gray-700 text-white border border-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 transition shadow-sm";
const textAreaClass =
  "w-full p-3 rounded-md bg-white/10 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-blue-500 transition shadow-sm resize-none";

const AddProperty = () => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    rent: "",
    advance: "",
    type: "Rent",
    bhkType: "",
    location: "",
    parking: "Yes",
    family: "Yes",
    bachelor: [],
    description: "",
    furnished: "Furnished",
    images: [],
    lat: null,
    lng: null,
    agentId: "", // new field
  });

  // Load agent ID from localStorage or context
  useEffect(() => {
    const agentId = localStorage.getItem("agentId");
    if (agentId) {
      setFormData(prev => ({ ...prev, agentId }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox" && name === "bachelor") {
      setFormData((prev) => ({
        ...prev,
        bachelor: checked
          ? [...prev.bachelor, value]
          : prev.bachelor.filter((item) => item !== value),
      }));
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleMapUrl = (e) => {
    const url = e.target.value;
    const match = url.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
    if (match) {
      const [_, lat, lng] = match;
      setFormData({ ...formData, lat: parseFloat(lat), lng: parseFloat(lng) });
    }
  };

  const handleImageUrlInput = (e) => {
    const urls = e.target.value
      .split(",")
      .map((url) => url.trim())
      .filter((url) => url);
    setFormData({ ...formData, images: urls });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const agentId = localStorage.getItem("agentId");
    if (!agentId) {
      toast.error("Agent ID missing. Please login again.");
      return;
    }

    const dataToSend = { ...formData, agentId };


    if (!formData.title.trim() || !formData.location.trim()) {
      toast.error("Title and location are required");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("http://localhost:5000/api/properties", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(dataToSend),
      });
      console.log("Data:", dataToSend);

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.msg || "Failed to add property");
      }

      toast.success("✅ Property added successfully!");

      setFormData({
        title: "",
        rent: "",
        advance: "",
        type: "Rent",
        bhkType: "",
        location: "",
        parking: "Yes",
        family: "Yes",
        bachelor: [],
        description: "",
        furnished: "Furnished",
        images: [],
        lat: null,
        lng: null,
        agentId: formData.agentId, // retain agentId
      });
    } catch (error) {
      toast.error(`❌ ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const LocationMarker = () => {
    useMapEvents({
      click(e) {
        setFormData({ ...formData, lat: e.latlng.lat, lng: e.latlng.lng });
      },
    });
    return formData.lat && formData.lng ? (
      <Marker position={[formData.lat, formData.lng]} />
    ) : null;
  };

  return (
    <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg max-w-5xl mx-auto shadow-lg border border-white/20 text-white">
      <Toaster position="top-right" />
      <h2 className="text-2xl font-bold mb-6">Add New Property</h2>
   
       <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input name="title" placeholder="Property Title" value={formData.title} onChange={handleChange} className={inputClass} />
        <input name="location" placeholder="Location" value={formData.location} onChange={handleChange} className={inputClass} />
        <input name="rent" placeholder="Rent / Month" type="number" value={formData.rent} onChange={handleChange} className={inputClass} />
        <input name="advance" placeholder="Advance" type="number" value={formData.advance} onChange={handleChange} className={inputClass} />
        <select name="type" value={formData.type} onChange={handleChange} className={selectClass}>
          <option value="Rent">Rent</option>
          <option value="Sell">Sell</option>
        </select>
        <select name="bhkType" value={formData.bhkType} onChange={handleChange} className={selectClass}>
          <option value="">Select BHK</option>
          <option value="1BHK">1BHK</option>
          <option value="2BHK">2BHK</option>
          <option value="3BHK">3BHK</option>
        </select>
        <select name="parking" value={formData.parking} onChange={handleChange} className={selectClass}>
          <option value="Yes">Car Parking - Yes</option>
          <option value="No">Car Parking - No</option>
        </select>
        <select name="family" value={formData.family} onChange={handleChange} className={selectClass}>
          <option value="Yes">Family Allowed</option>
          <option value="No">Family Not Allowed</option>
        </select>

        <div className="col-span-1 md:col-span-2">
          <label className="block mb-1">Bachelor Allowed</label>
          <div className="flex gap-4">
            <label className="flex items-center gap-2">
              <input type="checkbox" name="bachelor" value="3 persons" checked={formData.bachelor.includes("3 persons")} onChange={handleChange} />
              3 Persons
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="bachelor" value="5 persons" checked={formData.bachelor.includes("5 persons")} onChange={handleChange} />
              5 Persons
            </label>
          </div>
        </div>

        <select name="furnished" value={formData.furnished} onChange={handleChange} className={selectClass}>
          <option value="Furnished">Furnished</option>
          <option value="Semi-Furnished">Semi-Furnished</option>
          <option value="Unfurnished">Unfurnished</option>
        </select>

        <textarea
          name="description"
          placeholder="Description (e.g., 2 bathrooms, extra charges...)"
          value={formData.description}
          onChange={handleChange}
          className={textAreaClass + " col-span-1 md:col-span-2"}
          rows={4}
        />

        <textarea
          placeholder="Enter image URLs (comma separated)"
          onChange={handleImageUrlInput}
          className={textAreaClass + " col-span-1 md:col-span-2"}
          rows={2}
        />

        <input
          placeholder="Google Maps URL (with @lat,lng)"
          onChange={handleMapUrl}
          className={inputClass + " text-black col-span-1 md:col-span-2"}
        />

        <div className="col-span-1 md:col-span-2">
          <label className="block mb-1">Select Property Location</label>
          <MapContainer
            center={[formData.lat || 20.5937, formData.lng || 78.9629]}
            zoom={formData.lat ? 13 : 5}
            style={{ height: "300px", borderRadius: "8px" }}
            scrollWheelZoom={false}
          >
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <LocationMarker />
          </MapContainer>
          {formData.lat && formData.lng && (
            <p className="text-sm mt-2 text-white/80">
              Lat: {formData.lat.toFixed(4)}, Lng: {formData.lng.toFixed(4)}
            </p>
          )}
        </div>
        <button
          type="submit"
          disabled={loading}
          className={`bg-blue-600 text-white py-3 px-6 rounded-md font-semibold col-span-2 ${
            loading ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          {loading ? "Submitting..." : "Submit Property"}
        </button>
      </form>
    </div>
  );
};

export default AddProperty;
