// components/property/ContactFormPopup.jsx
import React, { useState } from "react";

const ContactFormPopup = ({ onClose, propertyId, toAgentId }) => {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    whatsapp: "",
    propertyId,
    toAgentId,
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok) throw new Error(data.msg || "Failed to submit form");
      alert("✅ Contact form submitted!");
      onClose();
    } catch (err) {
      alert("❌ " + err.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center">
<div className="bg-white rounded-lg p-6 w-full max-w-md shadow-xl z-[1000]">
        <button onClick={onClose} className="absolute top-2 right-4 text-xl font-bold text-red-500">
          ×
        </button>
        <h2 className="text-xl font-semibold mb-4">Contact Agent</h2>
        <input
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Your Name"
          className="w-full mb-2 p-2 border rounded"
        />
        <input
          name="phone"
          value={form.phone}
          onChange={handleChange}
          placeholder="Phone Number"
          className="w-full mb-2 p-2 border rounded"
        />
        <input
          name="email"
          value={form.email}
          onChange={handleChange}
          placeholder="Email"
          className="w-full mb-2 p-2 border rounded"
        />
        <input
          name="whatsapp"
          value={form.whatsapp}
          onChange={handleChange}
          placeholder="WhatsApp Number"
          className="w-full mb-4 p-2 border rounded"
        />
        <button
          onClick={handleSubmit}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Submit
        </button>
      </div>
    </div>
  );
};

export default ContactFormPopup;
