import React, { useState } from "react";
import { FaTimes, FaChevronLeft, FaChevronRight } from "react-icons/fa";
import { MapContainer, TileLayer, Marker } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import ContactFormPopup from "./ContactFormPopup";
const PropertyModal = ({ property, onClose }) => {
  const [imageIndex, setImageIndex] = useState(0);
  const [visitMessage, setVisitMessage] = useState("");
  const [showContactForm, setShowContactForm] = useState(false);

  const images = property.images?.length ? property.images : [
    "https://via.placeholder.com/300x200?text=No+Image"
  ];

  const nextImage = () => setImageIndex((prev) => (prev + 1) % images.length);
  const prevImage = () => setImageIndex((prev) => (prev - 1 + images.length) % images.length);

  const handleRequest = async () => {
  const userId = localStorage.getItem("userId");

  if (!userId) {
    alert("You must be logged in as a user to send a request.");
    return;
  }

  try {
    const res = await fetch("http://localhost:5000/api/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        fromUserId: userId,
        toAgentId: property.agentId,
        propertyId: property._id,
        message: visitMessage,
      }),
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.msg || "Request failed");

    alert("✅ Request sent successfully!");
    setVisitMessage("");

  } catch (err) {
    alert("❌ " + err.message);
  }
   setShowContactForm(true);
};


  const lat = property.lat || 20.5937;
  const lng = property.lng || 78.9629;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-full max-w-4xl relative overflow-y-auto max-h-[90vh]">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-red-600 text-xl"
        >
          <FaTimes />
        </button>

        {/* Image carousel */}
        <div className="relative">
          <img
            src={images[imageIndex]}
            alt="property"
            className="w-full h-64 object-cover rounded"
          />
          {images.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute top-1/2 left-2 transform -translate-y-1/2 bg-white/80 p-2 rounded-full"
              >
                <FaChevronLeft />
              </button>
              <button
                onClick={nextImage}
                className="absolute top-1/2 right-2 transform -translate-y-1/2 bg-white/80 p-2 rounded-full"
              >
                <FaChevronRight />
              </button>
            </>
          )}
        </div>

        {/* Property Info */}
        <div className="mt-4 space-y-2 text-gray-800">
          <h2 className="text-xl font-bold">{property.title}</h2>
          <p><strong>Location:</strong> {property.location}</p>
          <p><strong>Rent:</strong> ₹{property.rent}</p>
          <p><strong>Advance:</strong> ₹{property.advance}</p>
          <p><strong>Type:</strong> {property.type}</p>
          <p><strong>BHK:</strong> {property.bhkType}</p>
          <p><strong>Parking:</strong> {property.parking}</p>
          <p><strong>Family Allowed:</strong> {property.family}</p>
          <p><strong>For Bachelors:</strong> {property.bachelor?.join(", ")}</p>
          <p><strong>Furnishing:</strong> {property.furnished}</p>
          <p><strong>Description:</strong> {property.description}</p>
        </div>

        {/* Map */}
        <div className="mt-4">
          <h3 className="font-semibold mb-2">Location</h3>
          <MapContainer
            center={[lat, lng]}
            zoom={property.lat ? 13 : 5}
            style={{ height: "250px", borderRadius: "8px" }}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; OpenStreetMap contributors"
            />
            <Marker position={[lat, lng]} />
          </MapContainer>
        </div>

        {/* Request to Visit */}
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Request a Visit</h3>
          <textarea
            value={visitMessage}
            onChange={(e) => setVisitMessage(e.target.value)}
            placeholder="Enter your message/request to visit the property..."
            className="w-full p-2 border rounded mb-2"
            rows="3"
          />
          <button
            onClick={handleRequest}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
          >
            Send Request
          </button>
          <div className="mt-4 p-4 bg-white/10 rounded-lg text-sm text-gray-800">
    <h4 className="font-semibold mb-1 text-black">Agent Information</h4>
    <p><strong>Name:</strong> {property.agentName || "N/A"}</p>
    <p><strong>Contact:</strong> +91 XXXXXXXX</p>
    {/* Optional fields like email or agency can go here */}
  </div>
        </div>
      </div>
       {showContactForm && (
        <div className="fixed inset-0 bg-black/50 z-[999] flex items-center justify-center">
        <ContactFormPopup
          onClose={() => setShowContactForm(false)}
          propertyId={property._id}
          toAgentId={property.agentId}
        />
        </div>
      )}
    </div>
  );

};

export default PropertyModal;
