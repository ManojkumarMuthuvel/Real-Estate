import React, { useEffect, useState } from "react";

const AgentContactForms = () => {
  const [forms, setForms] = useState([]);
  const agentId = localStorage.getItem("agentId");

  useEffect(() => {
    fetch(`http://localhost:5000/api/contact/agent/${agentId}`)
      .then((res) => res.json())
      .then(setForms)
      .catch((err) => console.error("Error fetching contact forms:", err));
  }, [agentId]);

  return (
    <div className="p-6 text-white max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Contact Form Submissions</h2>

      {forms.length === 0 ? (
        <p className="text-white/70">No contact form submissions found.</p>
      ) : (
        <div className="space-y-6">
          {forms.map((form) => (
            <div
              key={form._id}
              className="bg-white/20 backdrop-blur p-4 rounded-lg border border-white/30"
            >
              <h3 className="text-xl font-semibold">{form.name}</h3>
              <p><strong>Email:</strong> {form.email || "N/A"}</p>
              <p><strong>Phone:</strong> {form.phone || "N/A"}</p>
              <p><strong>WhatsApp:</strong> {form.whatsapp || "N/A"}</p>
              <p><strong>Property:</strong> {form.propertyId?.title || "Unknown"}</p>
              <p><strong>Submitted:</strong> {new Date(form.createdAt).toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AgentContactForms;
