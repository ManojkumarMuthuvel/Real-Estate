import React, { useEffect, useState } from "react";
import PropertyCard from "./PropertyCard";

const PropertyGrid = ({ onPropertyClick }) => {
  const [properties, setProperties] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [filters, setFilters] = useState({
    search: "",
    price: "",
    bhkType: "",
  });

  useEffect(() => {
    fetch("http://localhost:5000/api/properties")
      .then((res) => res.json())
      .then((data) => {
        setProperties(data);
        setFiltered(data); // initialize display
      })
      .catch((err) => console.error("Error loading properties:", err));
  }, []);

  useEffect(() => {
    let result = [...properties];

    if (filters.search.trim()) {
      const term = filters.search.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(term) ||
          p.location.toLowerCase().includes(term)
      );
    }

    if (filters.bhkType) {
      result = result.filter((p) => p.bhkType === filters.bhkType);
    }

    if (filters.price) {
      if (filters.price === "500") result = result.filter((p) => p.rent <= 500);
      else if (filters.price === "500-1000")
        result = result.filter((p) => p.rent > 500 && p.rent <= 1000);
      else if (filters.price === "1000+")
        result = result.filter((p) => p.rent > 1000);
    }

    setFiltered(result);
  }, [filters, properties]);

  const handleChange = (e) => {
    setFilters((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <div>
      {/* Filters UI */}
      <div className="mb-6 flex gap-4 flex-wrap">
        <input
          type="text"
          name="search"
          value={filters.search}
          onChange={handleChange}
          placeholder="Search title or location..."
          className="border p-2 rounded w-full max-w-sm"
        />
        <select
          name="price"
          value={filters.price}
          onChange={handleChange}
          className="border p-2 rounded"
        >
          <option value="">Any Price</option>
          <option value="500">&lt; ₹500</option>
          <option value="500-1000">₹500 - ₹1000</option>
          <option value="1000+">₹1000+</option>
        </select>
        <select
          name="bhkType"
          value={filters.bhkType}
          onChange={handleChange}
          className="border p-2 rounded"
        >
          <option value="">All Types</option>
          <option value="1BHK">1BHK</option>
          <option value="2BHK">2BHK</option>
          <option value="3BHK">3BHK</option>
        </select>
      </div>

      {/* Property Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((property) => (
          <PropertyCard
            key={property._id}
            image={property.images?.[0] || "https://via.placeholder.com/300x200"}
            price={`₹${property.rent}`}
            address={property.location}
            id={property._id}
            onClick={() => onPropertyClick(property)}
          />
        ))}
      </div>
    </div>
  );
};

export default PropertyGrid;
