import React, { useEffect, useState } from "react";

const Requests = () => {
  const [requests, setRequests] = useState([]);
  const [userReplies, setUserReplies] = useState({}); // to track textarea per request

  const userId = localStorage.getItem("userId");

  useEffect(() => {
    fetch(`http://localhost:5000/api/requests/user/${userId}`)
      .then((res) => res.json())
      .then((data) => setRequests(data))
      .catch((err) => console.error("Failed to fetch requests:", err));
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case "Pending":
        return "text-yellow-400";
      case "Approved":
        return "text-green-400";
      case "Rejected":
        return "text-red-400";
      default:
        return "text-white";
    }
  };

  const handleUserReply = async (requestId) => {
    const reply = userReplies[requestId];
    if (!reply) return;

    try {
      const res = await fetch(`http://localhost:5000/api/requests/user-reply/${requestId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userReplyMessage: reply }),
      });

      const data = await res.json();

      if (res.ok) {
        alert("✅ Message sent to agent!");
        setUserReplies((prev) => ({ ...prev, [requestId]: "" }));

        // Refresh requests to get updated replies
        const updated = await fetch(`http://localhost:5000/api/requests/user/${userId}`);
        setRequests(await updated.json());
      } else {
        throw new Error(data.msg || "Reply failed");
      }
    } catch (err) {
      console.error("Reply error:", err.message);
      alert("❌ " + err.message);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg p-6 rounded-lg max-w-5xl mx-auto text-white">
      <h2 className="text-2xl font-bold mb-6">My Property Requests</h2>

      {requests.length === 0 ? (
        <p className="text-white/70">No requests found.</p>
      ) : (
        <div className="space-y-6">
          {requests.map((req) => (
            <div
              key={req._id}
              className="flex flex-col md:flex-row justify-between gap-4 bg-white/20 p-4 rounded-lg border border-white/30 shadow"
            >
              {/* Left: Property Details */}
              <div className="flex-1 space-y-1">
                <h3 className="text-xl font-semibold">{req.propertyId?.title}</h3>
                <p><strong>Rent:</strong> ₹{req.propertyId?.rent}</p>
                <p><strong>Advance:</strong> ₹{req.propertyId?.advance}</p>
                <p><strong>BHK Type:</strong> {req.propertyId?.bhkType}</p>
                <p><strong>Location:</strong> {req.propertyId?.location}</p>
  <div className="mt-2 bg-white/10 p-3 rounded">
    <p><strong>Agent:</strong> {req.toAgentId?.name || "N/A"}</p>
    <p><strong>Email:</strong> {req.toAgentId?.email || "Not available"}</p>
    {/* Optionally show phone, agency etc. */}
  </div>
                <p className={`mt-2 font-bold ${getStatusColor(req.status)}`}>
                  Status: {req.status}
                </p>

                {/* Agent response */}
                {req.responseMessage && (
                  <div className="mt-2 p-2 bg-white/10 rounded text-sm text-white/80">
                    <strong>Agent Response:</strong> {req.responseMessage}
                  </div>
                )}

                {/* User Reply Field */}
                <div className="mt-2">
                  <textarea
                    value={userReplies[req._id] || ""}
                    onChange={(e) =>
                      setUserReplies((prev) => ({
                        ...prev,
                        [req._id]: e.target.value,
                      }))
                    }
                    placeholder="Write your message to agent..."
                    className="w-full p-2 rounded bg-white text-black"
                    rows={2}
                  />
                  <button
                    onClick={() => handleUserReply(req._id)}
                    className="mt-2 px-4 py-1 bg-blue-600 rounded text-white"
                  >
                    Send
                  </button>
                </div>

                {/* Previously sent reply (if any) */}
                {req.userReplyMessage && (
                  <div className="mt-2 text-sm text-white/70 italic">
                    You: {req.userReplyMessage}
                  </div>
                )}
              </div>

              {/* Right: Property Image */}
              <div className="w-full md:w-60 flex-shrink-0">
                <img
                  src={
                    req.propertyId?.images?.[0] ||
                    "https://via.placeholder.com/300x200?text=No+Image"
                  }
                  alt="Property"
                  className="w-full h-40 object-cover rounded"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Requests;
