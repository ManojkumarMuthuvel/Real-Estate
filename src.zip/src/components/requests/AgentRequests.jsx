import React, { useEffect, useState } from "react";

const AgentRequests = () => {
  const [requests, setRequests] = useState([]);
  const [replyMessages, setReplyMessages] = useState({});
  const agentId = localStorage.getItem("agentId");

  useEffect(() => {
    fetch(`http://localhost:5000/api/requests/agent/${agentId}`)
      .then((res) => res.json())
      .then((data) => setRequests(data))
      .catch((err) => console.error("Failed to fetch agent requests:", err));
  }, [agentId]);

  const handleUpdateStatus = async (requestId, newStatus) => {
    try {
      const res = await fetch(`http://localhost:5000/api/requests/${requestId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });

      const result = await res.json();
      if (res.ok) {
        setRequests((prev) =>
          prev.map((r) => (r._id === requestId ? { ...r, status: newStatus } : r))
        );
      }
    } catch (err) {
      console.error("Update error:", err);
    }
  };

  const handleSendReply = async (requestId) => {
    const text = replyMessages[requestId]?.trim();
    if (!text) return;

    try {
      const res = await fetch(`http://localhost:5000/api/requests/user-reply/${requestId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ replyMessage: text }),
      });

      const result = await res.json();
      if (res.ok) {
        setRequests((prev) =>
          prev.map((r) =>
            r._id === requestId ? { ...r, replyMessage: text } : r
          )
        );
        setReplyMessages((prev) => ({ ...prev, [requestId]: "" }));
      }
    } catch (err) {
      console.error("Failed to send reply:", err);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Pending":
        return "text-yellow-400";
      case "Approved":
        return "text-green-400";
      case "Rejected":
        return "text-red-400";
      default:
        return "text-white";
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg p-6 rounded-lg max-w-5xl mx-auto text-white">
      <h2 className="text-2xl font-bold mb-6">User Requests for Your Properties</h2>

      {requests.length === 0 ? (
        <p className="text-white/70">No requests found.</p>
      ) : (
        <div className="space-y-6">
          {requests.map((req) => (
            <div
              key={req._id}
              className="flex flex-col md:flex-row justify-between gap-4 bg-white/20 p-4 rounded-lg border border-white/30 shadow"
            >
              {/* Left */}
              <div className="flex-1 space-y-1">
                <h3 className="text-xl font-semibold">
                  {req.fromUserId?.name} requested: {req.propertyId?.title}
                </h3>
                <p><strong>Rent:</strong> ₹{req.propertyId?.rent}</p>
                <p><strong>Advance:</strong> ₹{req.propertyId?.advance}</p>
                <p><strong>BHK:</strong> {req.propertyId?.bhkType}</p>
                <p><strong>Location:</strong> {req.propertyId?.location}</p>
                <p><strong>User Message:</strong> {req.message}</p>

                <p className={`mt-2 font-bold ${getStatusColor(req.status)}`}>
                  Status: {req.status}
                </p>

                {req.replyMessage && (
                  <p className="text-green-300 mt-1">
                    <strong>Your Reply:</strong> {req.replyMessage}
                  </p>
                )}

                {/* Approve/Reject buttons */}
                {req.status === "Pending" && (
                  <div className="flex gap-3 mt-3">
                    <button
                      onClick={() => handleUpdateStatus(req._id, "Approved")}
                      className="bg-green-600 hover:bg-green-700 text-white px-4 py-1 rounded"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(req._id, "Rejected")}
                      className="bg-red-600 hover:bg-red-700 text-white px-4 py-1 rounded"
                    >
                      Reject
                    </button>
                  </div>
                )}

                {/* Agent Response Input */}
                <div className="mt-3">
                  <textarea
                    value={replyMessages[req._id] || ""}
                    onChange={(e) =>
                      setReplyMessages((prev) => ({
                        ...prev,
                        [req._id]: e.target.value,
                      }))
                    }
                    placeholder="Type your reply to the user..."
                    className="w-full p-2 rounded bg-white text-black"
                    rows={2}
                  />
                  <button
                    onClick={() => handleSendReply(req._id)}
                    className="mt-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded"
                  >
                    Send Reply
                  </button>
                </div>
              </div>

              {/* Right: Image */}
              <div className="w-full md:w-60 flex-shrink-0">
                <img
                  src={
                    req.propertyId?.images?.[0] ||
                    "https://via.placeholder.com/300x200?text=No+Image"
                  }
                  alt="Property"
                  className="w-full h-40 object-cover rounded"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AgentRequests;
