import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import UserDashboard from "./pages/UserDashboard";
import AgentLogin from "./pages/AgentLogin";
import AgentRegister from "./pages/AgentRegister";
import { Toaster } from "react-hot-toast";

function App() {
  return (
    <Router>
       <Toaster position="top-right" />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path='/user-dashboard' element={<UserDashboard/>}/>
        <Route path='/agent-login' element={<AgentLogin/>}/>
        <Route path="/agent-register" element={<AgentRegister/>}/>
      </Routes>
    </Router>
  );
}

export default App;
